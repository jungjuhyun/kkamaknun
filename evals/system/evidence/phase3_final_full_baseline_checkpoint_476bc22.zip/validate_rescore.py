import json
import sys
from pathlib import Path

from inspect_ai.log import read_eval_log


base = Path(sys.argv[1])
summary = json.loads((base / "full_run" / "summary.json").read_text(encoding="utf-8"))
comparisons = []
for index, record in enumerate(summary["inspect_logs"], 1):
    original = read_eval_log(str(base / "full_run" / record["path"]))
    rescored = read_eval_log(str(base / "rescored" / f"rescore_{index:02d}.eval"))

    def statuses(log):
        return [sample.scores[next(iter(sample.scores))].answer for sample in (log.samples or [])]

    before = statuses(original)
    after = statuses(rescored)
    comparisons.append({
        "index": index,
        "sample_count": len(before),
        "identical": before == after,
        "target_calls": 0,
    })

print(json.dumps({
    "log_count": len(comparisons),
    "sample_count": sum(item["sample_count"] for item in comparisons),
    "all_identical": all(item["identical"] for item in comparisons),
    "target_calls": 0,
}, indent=2))
